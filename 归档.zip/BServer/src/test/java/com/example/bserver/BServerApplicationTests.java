package com.example.bserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
