package com.example.aserver.constant;


public class CommonConstant {

    public static final String NUMBER_OF_SHARDS = "number_of_shards";

    public static final String NUMBER_OF_REPLICAS = "number_of_replicas";
}
