scp target/demo-0.0.1-SNAPSHOT.jar root@10.211.55.5:/usr/local/jar
