package com.example.aserver.service;


public interface LoginService {

    LoginRetuen login(String username,String clientId);
}
