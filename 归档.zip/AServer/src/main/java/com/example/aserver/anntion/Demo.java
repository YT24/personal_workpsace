package com.example.aserver.anntion;

@Info
public class Demo {

}
