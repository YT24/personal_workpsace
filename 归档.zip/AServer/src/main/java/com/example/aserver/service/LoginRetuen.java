package com.example.aserver.service;

public interface LoginRetuen {

}
